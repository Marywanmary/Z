class gazeClass extends WebApiBase {
    constructor() {
        super()
        this.webSite = 'https://gaze.run'
        this.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        }
    }

    async getClassList(args) {
        const webUrl = args.url || this.webSite
        let backData = new RepVideoClassList()
        try {
            const pro = await req(webUrl, { headers: this.headers })
            backData.error = pro.error
            const proData = pro.data
            if (proData) {
                const $ = cheerio.load(proData)
                let allClass = $('.nav-menu a, .category-menu a') // 请根据实际网站结构调整选择器
                let list = []
                allClass.each((index, element) => {
                    const cat = $(element)
                    let name = cat.text().trim()
                    let url = cat.attr('href')
                    if (url && name && !url.includes('javascript')) {
                        let videoClass = new VideoClass()
                        videoClass.type_id = url.replace(this.webSite, '')
                        videoClass.type_name = name
                        list.push(videoClass)
                    }
                })
                backData.data = list
            }
        } catch (e) {
            backData.error = e.message
        }
        return JSON.stringify(backData)
    }

    async getVideoList(args) {
        let listUrl = args.url.startsWith('http') ? args.url : this.webSite + args.url
        if (args.page) {
            listUrl += (listUrl.includes('?') ? '&' : '?') + `page=${args.page}`
        }
        let backData = new RepVideoList()
        try {
            let pro = await req(listUrl, { headers: this.headers })
            backData.error = pro.error
            let proData = pro.data
            if (proData) {
                const $ = cheerio.load(proData)
                let allVideo = $('.video-item, .movie-list-item') // 请根据实际网站结构调整选择器
                let videos = []
                allVideo.each((_, e) => {
                    let aTag = $(e).find('a').first()
                    let url = aTag.attr('href')
                    let name = aTag.attr('title') || aTag.find('img').attr('alt') || aTag.text().trim()
                    let pic = aTag.find('img').attr('src') || aTag.find('img').attr('data-original')
                    let remarks = $(e).find('.remarks, .video-remarks, .tag').text().trim()
                    
                    if (url && name) {
                        let videoDet = new VideoDetail()
                        videoDet.vod_id = url.replace(this.webSite, '')
                        videoDet.vod_pic = pic
                        videoDet.vod_name = name
                        videoDet.vod_remarks = remarks
                        videos.push(videoDet)
                    }
                })
                backData.data = videos
            }
        } catch (e) {
            backData.error = '获取列表失败～' + e.message
        }
        return JSON.stringify(backData)
    }

    async getVideoDetail(args) {
        let backData = new RepVideoDetail()
        const webUrl = args.url.startsWith('http') ? args.url : this.webSite + args.url
        try {
            const pro = await req(webUrl, { headers: this.headers })
            backData.error = pro.error
            const proData = pro.data
            if (proData) {
                const $ = cheerio.load(proData)
                let detModel = new VideoDetail()

                detModel.vod_name = $('h1, .video-title').first().text().trim()
                detModel.vod_pic = $('.video-poster img, .video-cover img').first().attr('src') || $('.video-poster img, .video-cover img').first().attr('data-original')
                detModel.vod_content = $('.video-intro, .video-desc').first().text().trim()
                detModel.vod_director = $('.video-info li:contains("导演")').first().text().replace('导演：', '').trim()
                detModel.vod_actor = $('.video-info li:contains("主演")').first().text().replace('主演：', '').trim()
                detModel.vod_year = $('.video-info li:contains("年份")').first().text().replace('年份：', '').trim()
                detModel.vod_area = $('.video-info li:contains("地区")').first().text().replace('地区：', '').trim()

                let playlist = $('.episode-list, .play-list')
                let vod_play_url = []
                let from = []
                playlist.each((index, element) => {
                    let playFrom = $(element).prev('h3, .play-title').text().trim() || `线路${index + 1}`
                    from.push(playFrom)
                    let eps = $(element).find('a')
                    let temp = ''
                    eps.each((_, e) => {
                        let name = $(e).text().trim()
                        let url = $(e).attr('href')
                        if (name && url) {
                            temp += `${name}$${url.replace(this.webSite, '')}#`
                        }
                    })
                    vod_play_url.push(temp)
                })

                detModel.vod_play_from = from.join('$$$')
                detModel.vod_play_url = vod_play_url.join('$$$')
                detModel.vod_id = args.url

                backData.data = detModel
            }
        } catch (e) {
            backData.error = '获取视频详情失败' + e.message
        }
        return JSON.stringify(backData)
    }

    async getVideoPlayUrl(args) {
        let backData = new RepVideoPlayUrl()
        let reqUrl = args.url.startsWith('http') ? args.url : this.webSite + args.url

        try {
            const pro = await req(reqUrl, { headers: this.headers })
            backData.error = pro.error
            let proData = pro.data
            if (proData) {
                const $ = cheerio.load(proData)
                let iframe = $('iframe').attr('src')
                if (!iframe) {
                    // 有些网站可能用其他方式嵌入播放器
                    let scriptText = $('script').text()
                    let match = scriptText.match(/url:\s*['"](.*?)['"]/, /src:\s*['"](.*?)['"]/, /["']([^"']*\.m3u8[^"']*?)['"]/)
                    if (match && match[1]) {
                        backData.data = match[1]
                        backData.headers = this.headers
                        return JSON.stringify(backData)
                    }
                }
                
                if (iframe) {
                    // 如果iframe的src是相对路径，需要拼接
                    if (iframe.startsWith('/')) {
                        iframe = new URL(iframe, this.webSite).href
                    }
                    let player = await req(iframe, { headers: this.headers })
                    if (player.data) {
                        const $p = cheerio.load(player.data)
                        // 尝试从播放器页面直接找到m3u8地址
                        let videoUrl = $p('source').attr('src') || $p('video').attr('src')
                        if (videoUrl) {
                            backData.data = videoUrl
                            backData.headers = this.headers
                        } else {
                            // 如果找不到，尝试从脚本中解析
                            let scriptText = $p('script').text()
                            let match = scriptText.match(/["']([^"']*\.m3u8[^"']*?)['"]/)
                            if (match && match[1]) {
                                backData.data = match[1]
                                backData.headers = this.headers
                            }
                        }
                    }
                }
            }
        } catch (e) {
            UZUtils.debugLog(e)
            backData.error = e.message
        }
        return JSON.stringify(backData)
    }

    async searchVideo(args) {
        let backData = new RepVideoList()
        try {
            let searchUrl = `${this.webSite}/search?wd=${encodeURIComponent(args.searchWord)}`
            let pro = await req(searchUrl, { headers: this.headers })
            backData.error = pro.error
            let body = pro.data
            if (body) {
                let $ = cheerio.load(body)
                let allVideo = $('.video-item, .search-result-item') // 请根据实际网站结构调整选择器
                let videos = []
                allVideo.each((_, e) => {
                    let aTag = $(e).find('a').first()
                    let url = aTag.attr('href')
                    let name = aTag.attr('title') || aTag.find('img').attr('alt') || aTag.text().trim()
                    let pic = aTag.find('img').attr('src') || aTag.find('img').attr('data-original')
                    let remarks = $(e).find('.remarks, .video-remarks, .tag').text().trim()

                    if (url && name) {
                        let videoDet = new VideoDetail()
                        videoDet.vod_id = url.replace(this.webSite, '')
                        videoDet.vod_pic = pic
                        videoDet.vod_name = name
                        videoDet.vod_remarks = remarks
                        videos.push(videoDet)
                    }
                })
                backData.data = videos
            }
        } catch (e) {
            backData.error = e.message
        }
        return JSON.stringify(backData)
    }
}
let gaze20250416 = new gazeClass()